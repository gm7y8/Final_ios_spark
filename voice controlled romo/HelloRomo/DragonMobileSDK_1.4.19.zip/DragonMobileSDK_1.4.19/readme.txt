Welcome to the Dragon Mobile SDK from Nuance Communications Inc.  


Dragon Mobile SDK Reference.html
	Help documentation for the Dragon Mobile SDK.  This includes getting started guides, general 
	usage instruction and details the example applications.

Speech Kit Framework Reference.html
	Reference for the Speech Kit framework.  This provides the API documenation and usage for the 
	Speech Kit framework.

Help
	The resources for the above help guides.

DragonMobileRecognizer
	The example recognition application showcasing the SKRecognizer class use.

DragonMobileVocalizer
	The example text-to-speech application showcasing the SKVocalizer class use.

SpeechKit.framework
	The Speech Kit framework.  You should copy this framework into your project.

License.pdf
	This is the standard license agreement governing the use and distribution of the 
	Dragon Mobile SDK.


For more information and up-to-date documenation see:
http://dragonmobile.nuancemobiledeveloper.com
